# Compilação dos exemplos

Use GCC num sistema x86-64 com suporte a AVX, AVX2 e FMA. No Linux, as extensões aparecem em `/proc/cpuinfo`. No Windows, podem ser conferidas no CPU-Z e os comandos podem ser executados no terminal MSYS2 UCRT64.

Execute a partir da raiz do repositório:

```sh
gcc -std=c11 -O2 -fno-tree-vectorize -mavx AVX/exemplo_avx.c -o avx
./avx

gcc -std=c11 -O2 -fno-tree-vectorize -mavx2 AVX2/exemplo_avx2.c -o avx2
./avx2

gcc -std=c11 -O2 -fno-tree-vectorize -ffp-contract=off -mavx -mfma FMA/exemplo_fma.c -lm -o fma
./fma
```

No Windows, use `avx.exe`, `avx2.exe` e `fma.exe` como nomes dos executáveis tanto na compilação quanto na execução. O exemplo AVX reserva memória alinhada com `aligned_alloc` em Linux e `_aligned_malloc` no Windows. Os exemplos AVX2 e FMA usam intrínsecas de carga e escrita que aceitam endereços desalinhados a 32 bytes.
